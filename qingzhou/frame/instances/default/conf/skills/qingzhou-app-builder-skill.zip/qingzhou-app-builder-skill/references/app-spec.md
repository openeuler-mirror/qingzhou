# 轻舟应用开发规范

## 概述

轻舟对业务系统的管控通过调度对应的“轻舟应用”完成。轻舟应用是基于轻舟 API（`qingzhou-api`）开发的 Java 应用，API 统一提供接口、UI 元数据与集成方式，实现多品类业务系统的标准化、一致化管理。

应用的四类元素与管控台的映射关系：

| 元素   | 实现方式                      | 管控台呈现        |
|------|---------------------------|--------------|
| 应用入口 | 实现 `QingzhouApp` + `@App` | 应用卡片         |
| 业务模块 | 继承 `ModelBase` + `@Model` | 功能菜单 / 页面    |
| 模块字段 | public 属性 + `@ModelField` | 表单字段 / 列表列   |
| 模块操作 | 能力接口或 `@ModelAction` 方法   | REST 接口 / 按钮 |

除入口类外，应用无需编写 Controller：模块操作在构建期被提取为元数据（`QZ-INF/annotation.json`），运行期由框架统一暴露为 REST 接口。

## 快速开始

### 1. 引入依赖

应用工程中，`qingzhou-api` 以 `provided` 引入（由平台提供）：

```xml
<dependency>
    <groupId>qingzhou</groupId>
    <artifactId>qingzhou-api</artifactId>
    <version>${qingzhou.version}</version>
    <scope>provided</scope>
</dependency>
```

### 2. 编写应用入口

- 实现 `QingzhouApp`，重写 `start()`，可重写 `stop()`。
- 添加 `@App`、`@Menu` 注解配置元数据。
- 全应用只允许一个 `@App` 类，重复会导致应用部署时元数据解析失败。

### 3. 编写业务模块

- 继承 `ModelBase`，添加 `@Model`。
- 按业务需要实现能力接口（`Page`、`Show`、`Add`、`Update`、`Delete`、`Monitor` 等），实现即自动生成对应动作与按钮。
- public 字段 + `@ModelField` 定义业务数据；框架通过 public 字段读写，字段名默认即数据 key。
- `public` 方法 + `@ModelAction` 定义自定义操作，方法参数有且只能有一个 `Request`。

```java
@Menu(name = {"基础功能", "en:Basic"}, code = "basic", icon = "User", order = 1)
@App(roles = "admin", icon = "DataBoard",
        name = {"示例应用", "en:Demo Application"},
        info = {"用于演示轻舟应用开发。", "en:Demos Qingzhou app development."})
public class DemoApp implements QingzhouApp {
    @Override
    public void start(AppContext context) {
        context.getService(Logger.class).info("demo app started");
    }
}

@Model(code = "student", menu = "basic", name = {"学生", "en:Student"})
public class Student extends ModelBase implements Page, Show, Add, Update, Delete {
    @ModelField(id = true, readonly = true, list = true, name = {"ID", "en:ID"})
    public String id;

    @ModelField(name = {"姓名", "en:Name"}, required = true, list = true, search = true)
    public String name;

    @ModelAction(code = "graduate", icon = "Check", list = true,
            name = {"毕业", "en:Graduate"}, confirm = {"确认该学生毕业？", "en:Graduate this student?"})
    public void graduate(Request request) {
        // request.getId() 即被操作记录 ID
    }
}
```

### 4. 构建与部署

1. 在工程目录执行 `mvn clean package` 完成编译（JDK 1.8）。
2. 将生成的 jar 放入 `${轻舟产品包}/instances/<实例>/apps` 目录。
3. 重启轻舟，管控台可见开发的应用。

启动时引擎会把 `apps` 下的 jar 自动转换为 OSGi bundle（产物缓存在 `temp/app-bundle-cache`），OSGi 清单由转换器补齐，部署只需普通 jar。自动发现所需的 `Qingzhou-Detection-*` 仍须在 `pom.xml` 中声明，见 `detection.md`。

## 核心接口

### QingzhouApp

```java
void start(AppContext appContext) throws Exception; // 必须实现，抛异常即应用启动失败

default void stop() {
}                              // 可选，bundle 停止时调用
```

### AppContext

| 方法                                             | 说明                                                                              |
|------------------------------------------------|---------------------------------------------------------------------------------|
| `Map<String,String> getAppConfig()`            | 只读应用配置，来自实例配置 `app~<bundle 符号名>`；`code` 键可覆盖 `@App.code`，多探测实例时 code 追加 `:<序号>` |
| `String getDetectedPath()`                     | 自动发现的目标软件安装目录，未发现为 `null`（见 `detection.md`）                                     |
| `File getRoot()`                               | 实例根目录 (`instances/<实例>`)                                                        |
| `File getTempDir()`                            | 应用私有临时目录 `<root>/temp/apps/<appCode>`                                         |
| `<T> T getService(Class<T> type)`              | 获取平台共享服务，如 `qingzhou.logger.Logger`、`qingzhou.json.Json`；服务未注册返回 `null`         |
| `<T> T getService(Class<T> type, String name)` | 获取指定名字/多实例服务，如 `qingzhou.jdbc.JdbcPool` 的实例名                                    |
| `void addActionFilter(ActionFilter...)`        | 注册应用级请求过滤器，可多次调用，按注册顺序执行                                                        |

### ModelBase

所有模块必须继承。框架注入 `AppContext` 并回调生命周期：

- `getAppContext()`：模块内获取上下文。
- `getCurrentRequest()`：当前请求，仅在自定义 `@ModelAction` 方法执行期间有值（线程局部，框架负责清理，业务代码只读）。
- `start()` / `stop()`：模块启停回调，随应用启停逐模块调用。

### Request

| 方法                               | 说明             |
|----------------------------------|----------------|
| `getModel()/getAction()/getId()` | 请求路径段          |
| `getParameter(String)`           | 单值参数；同名多值只取第一个 |
| `getParameters()`                | 全部参数（单值只读 Map）  |
| `getResponse()`                  | 响应对象           |

### Response

链式 API：`success(boolean)`、`data(Object)`、`message(String)`、`messageLevel(MessageLevel)`、`status(int)`、`contentType(String)`、`header(String,String)`、`error(String)`。

- `error(msg)` 等价于 `message(msg) + messageLevel(error) + success(false)`。
- 动作执行后未设置 `data` 与 `msg` 时，框架返回 404，避免“静默成功”。
- `status`/`contentType`/`header` 主要用于文件下载等非 JSON 响应。

### ActionFilter

```java
void doFilter(Request request, FilterChain chain) throws Throwable;
```

在 `start()` 中通过 `appContext.addActionFilter(...)` 注册，位于框架内置校验之后、业务动作之前。不调用 `chain.doFilter()` 即中断请求；过滤器抛出的异常由框架统一转为 500，不要吞掉。

## 元数据注解

注解的 `@Retention` 均为 CLASS，在构建期被提取为元数据；属性中的 `name`/`info` 为国际化数组，元素格式 `"文案"`（默认简体中文）或 `"en:Text"`、`"zh_Hant:文案"`。

| 注解             | 目标 | 属性                                                                              |
|----------------|----|---------------------------------------------------------------------------------|
| `@App`         | 类  | `code`（缺省为 jar 名）、`roles`、`icon`、`name`（必填）、`info`                              |
| `@Menu`        | 类  | `name`（必填）、`code`（必填）、`icon`、`order`（默认 9）、`parent`（父菜单 code，支持多级）；可重复标注        |
| `@I18n`        | 类  | `code`、`name`（必填）；供字段 `group`/`chart_title` 引用；可重复标注                            |
| `@Model`       | 类  | `code`（缺省为类简名）、`roles`、`icon`、`menu`（所属菜单 code）、`order`（默认 9）、`name`（必填）、`info` |
| `@ModelField`  | 字段 | 见下表                                                                             |
| `@ModelAction` | 方法 | 见下表                                                                             |

### @ModelField

| 属性                                    | 默认             | 说明                                                     |
|---------------------------------------|----------------|--------------------------------------------------------|
| `code`                                | 字段名            | 数据 key，与 `Request` 参数、`Show`/`Monitor` 返回 Map 的 key 一致 |
| `name` / `info`                       | 必填 / 空         | 国际化名称与说明                                               |
| `field_type`                          | `form`         | `form` 表单字段；`monitor` 监视字段                             |
| `input_type`                          | `text`         | 控件类型，见「控件类型」                                           |
| `file`                                | `false`        | 文件字段标记；实际上传判定按 `input_type = file`                     |
| `display`                             | `""`           | 显示条件表达式，仅表达式为真时该字段的 `required` 才校验；空串恒真                |
| `readonly`                            | `false`        | 表单只读（传值，不参与校验）                                         |
| `required`                            | `false`        | 必填                                                     |
| `options`                             | `{}`           | 候选项，同时作为取值校验                                           |
| `separator`                           | `","`          | 多值分隔符                                                  |
| `min_value` / `max_value`             | 长整型极值          | 数值范围                                                   |
| `min_length` / `max_length`           | -1 / 整型最大值    | 长度范围                                                   |
| `host` / `port` / `email` / `pattern` | `false` / `""` | 主机名或 IP、端口 1-65535、邮箱、自定义正则（≤256 字符）校验                 |
| `id`                                  | `false`        | 记录 ID，须满足 `^[a-zA-Z0-9_-]{1,20}$`                      |
| `add` / `update` / `show`             | `true`         | 是否参与对应动作                                               |
| `list` / `search`                     | `false`        | 是否作为列表列 / 查询条件                                         |
| `ref_model`                           | `""`           | 候选取值来自指定模块的全部 id                                       |
| `link_to`                             | `""`           | 点击字段值跳转到 `modelCode.fieldCode` 列表并筛选                   |
| `numeric`                             | `false`        | 监视字段中的数值指标（可绘图表、可导出监控指标）                               |
| `chart_type`                          | `line`         | 仅 `numeric=true` 有效：`line`/`bar`/`gauge`/`stat`/`pie`  |
| `group` / `chart_title`               | `""`           | 表单分组 / 图表标题，引用 `@I18n.code`                            |
| `color`                               | `{}`           | 样式映射，如 `{"onsale:#67C23A"}`                            |
| `width_percent`                       | `-1`           | 列宽百分比                                                  |

注解只描述结构，不提供源数据查询能力：唯一性校验、跨记录一致性等必须在 Action 内自行实现。

### 控件类型（input_type）

| 分类 | 取值                                                                                                                    |
|----|-----------------------------------------------------------------------------------------------------------------------|
| 文本 | `text`、`textarea`、`password`、`number`（非 0 开头整数）、`decimal`（正数或小数）、`markdown`                                           |
| 时间 | `datetime`、`range_datetime`                                                                                           |
| 选择 | `bool`（`true`/`false`）、`radio`、`checkbox`、`sortable_checkbox`、`select`、`multiselect`、`sortable`、`grouped_multiselect` |
| 文件 | `file`（触发 multipart 上传，见「文件上传」）                                                                                       |
| 其他 | `kv`、`combine`                                                                                                        |

### @ModelAction

| 属性                             | 默认       | 说明                        |
|--------------------------------|----------|---------------------------|
| `code`                         | 方法名      | 动作标识，与内置动作同名即覆盖内置实现       |
| `roles`                        | `""`     | 可访问角色，逗号分隔，`*` 表示任意已认证用户  |
| `icon` / `order`               | `""` / 9 | 按钮图标与排序                   |
| `display`                      | `""`     | 按钮可用条件表达式，仅控制 UI 显隐，不构成权限 |
| `list` / `list_head` / `batch` | `false`  | 行内按钮 / 列表头部按钮 / 是否按勾选批量执行 |
| `add` / `update` / `show`      | `false`  | 是否出现在对应表单页                |
| `name` / `info`                | `{}`     | 国际化名称与说明                  |
| `confirm`                      | `{}`     | 非空时前端执行前弹确认框              |

### 显示条件表达式

`display` 支持：`字段`（非空即真）、`!字段`、`字段==值`、`字段!=值`，用 `&`/`&&`（与，优先级高）、`|`/`||`（或）组合，不支持括号和大小比较。操作数为字段原始字符串值。

## 能力接口

| 接口          | 动作 code               | 方法                                                                                                                                                                        |
|-------------|-----------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| `Page`      | `page`                | `List<String[]> page(int pageNum, int pageSize, Map<String,String> query, String[] listFields)`；`default int total(query)`（返回 -1 不分页）；`boolean contains(String id)`（框架预留） |
| `Show`      | `show`                | `Map<String,String> show(String id)`                                                                                                                                      |
| `Add`       | `add`                 | `void add(Map<String,String> data)`                                                                                                                                       |
| `Update`    | `update`              | `void update(String id, Map<String,String> data)`                                                                                                                         |
| `Delete`    | `delete`              | `void delete(String id)`，批量删除由框架逐条调用                                                                                                                                      |
| `Monitor`   | `monitor`             | `Map<String,String> monitor(String id)`                                                                                                                                   |
| `Download`  | `file`、`download`     | `File file(String id)`：返回文件或父目录（列目录，不递归子目录）                                                                                                                               |
| `Namespace` | `namespace`、`current` | `void namespace(String id)`、`String current()`                                                                                                                            |

约定：

- `page` 返回的每个 `String[]` 必须与 `listFields` 顺序严格一致；`query` 只包含 `search=true` 且非空的条件。
- 分页参数 `pageNum` 默认 1，`pageSize` 默认 10、上限 100；`total` 返回 -1 表示不分页。
- `Add`/`Update` 的 `data` 只包含 `add=true`/`update=true` 且本次请求传了值的字段（支持部分字段提交，未传字段由应用补默认值）；`Update` 会剔除 `id` 字段。
- 实现能力接口即生成内置动作（含按钮、图标、确认文案）；可用同 code 的 `@ModelAction` 覆盖内置实现，例如自定义 `file` 动作控制下载入口。

### REST 入口

框架为每个动作暴露统一入口，应用无需感知：

```
POST /registry/invoke/{instance}/{app}/{model}/{action}/{id}
```

- 参数可来自 URL query 与 POST body（表单或 JSON）。
- 响应体：`{"success":bool, "data":..., "msg":..., "msgLevel":...}`。
- 权限拒绝返回 403；动作未执行且无返回内容返回 404。
- 同一套动作同时被管控台、AI 工具与监控采集复用，应用侧无需为不同调用方重复实现。

### 文件上传

字段声明 `input_type = file` 即为上传字段。请求以 multipart 提交后：

- 参数值是该文件在服务端的临时路径，多文件以 `,` 分隔；
- 上传字段由框架按 `input_type = file` 判定，应用从 `getParameters()` 取值，不要按路径或扩展名猜测；
- 临时文件位于 `<实例>/temp/qingzhou-upload`，超过 24 小时由框架清理，需要长期保留的文件必须由应用自行搬移；
- 上传文件名、路径的合法性（含目录穿越、符号链接）由应用侧负责校验。

### Monitor 数据契约

`Monitor.monitor()` 返回的 `Map` 以 `@ModelField.code` 为 key，框架按 `field_type = monitor` 的字段白名单过滤后交给管控台。监控抓取端点只导出 `numeric = true` 的字段：

- 数值字段的值必须是十进制数值字符串（可带符号、小数、科学计数法），不得带单位、时间文本、JSON 或布尔词。
- 采集不到时省略该 key，不得填 `-1` 等哨兵值；否则会被当作真实指标导出或计入 `qingzhou_monitor_dropped_samples_total`。
- 指标名统一为 `qingzhou_<规范化字段 code>`：字段 code 会转小写、camelCase 转下划线、非法字符替换为 `_`，且无论原名是否带前缀都补齐 `qingzhou_`；端点只输出 `# TYPE`，不输出 `# HELP`。应用侧只负责字段命名与取值，不要自行拼接指标名。

## 权限

- `@App.roles`、`@Model.roles`、`@ModelAction.roles` 声明可访问角色，逗号分隔，`*` 表示任意已认证用户。
- 逐级继承：动作未声明则继承模块，模块未声明则继承应用。
- **未声明即拒绝（fail-closed）**：应用级至少要声明一次 `roles`，否则所有请求返回 403；新增模块/动作不要依赖“默认放行”。
- REST 调用、AI 工具调用、监控采集共用同一判定，不存在旁路。
- `display` 只影响按钮显隐，不承担鉴权；敏感操作必须同时声明 `roles`。

## 图标

`qingzhou.api.App.icon`、`qingzhou.api.Menu.icon`、`qingzhou.api.Model.icon`、`qingzhou.api.ModelAction.icon` 等属性用于设置图标。轻舟前端使用 **Element Plus Icons** 渲染，可直接使用官方图标名，参考：https://element-plus.org/zh-CN/component/icon.html#icon-collection

## 自动发现

应用需要管理独立部署的外部软件时，通过 `Qingzhou-Detection-*` 清单项由引擎周期探测目标安装目录，详见 `detection.md`。

## 开发检查清单

- 应用级已声明 `roles`，敏感动作单独声明。
- `@ModelField.code` 与 `Show`/`Monitor` 返回 Map 的 key、`Page` 列顺序一致。
- 金额、指标等数值字段使用 `decimal`/`number`，`numeric` 字段返回纯数值字符串。
- 自定义动作只声明一个 `Request` 参数，返回值通过 `request.getResponse()` 输出。
- 上传字段由 `input_type = file` 声明并取值，下载通过 `Download` 实现，不自行拼路径。
- 关键失败直接抛出异常，不静默降级；日志不打印密码、Token 等敏感信息。
